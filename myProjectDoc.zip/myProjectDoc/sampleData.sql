INSERT INTO public.concert_header(
	id, concert_name, concert_place, description, created_at, updated_at)
	VALUES (12, 'NameConcert', 'Jakarta', '', now(), now());
	
INSERT INTO public.concert_detail(
	id, concert_header_id, concert_date, concert_beg_time, price, tickets_amount, created_at, updated_at)
	VALUES (12, 12, now(), now(), 100000.00, 100, now(), now());

INSERT INTO public.mst_user(
	id, username, password, email, created_at, updated_at)
	VALUES (1, 'user001', 'password', 'user@gmail.com', now(), now());