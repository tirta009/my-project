CREATE TABLE concert_header
(
    id serial PRIMARY KEY,
    concert_name varchar(100) NOT NULL,
    concert_place varchar(100) NOT NULL,
    description text,
    created_at timestamp DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE concert_detail
(
    id serial PRIMARY KEY ,
    concert_header_id integer NOT NULL,
    concert_date date NOT NULL,
    concert_beg_time time NOT NULL,
    price numeric(10, 2) NOT NULL,
    tickets_amount integer NOT NULL,
    created_at timestamp DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp DEFAULT CURRENT_TIMESTAMP,
	FOREIGN KEY (concert_header_id) REFERENCES concert_header(id),
	UNIQUE (concert_header_id, concert_date, concert_beg_time) 
);

CREATE TABLE mst_user
(
    id serial PRIMARY KEY ,
    username varchar(100) NOT NULL,
    password varchar(100) NOT NULL,
    email varchar(100) NOT NULL,
    created_at timestamp DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE transaction_concert
(
    id serial PRIMARY KEY,
    transaction_date timestamp NOT NULL,
    concert_detail_id integer NOT NULL,
    user_id integer NOT NULL,
    ticket_amount integer NOT NULL,
    total_payment numeric(10, 2) NOT NULL,
    status_payment varchar(100) NOT NULL,
    method_payment varchar(100) NOT NULL,
	created_at timestamp DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp DEFAULT CURRENT_TIMESTAMP,
	FOREIGN KEY (concert_detail_id) REFERENCES concert_detail(id),
	FOREIGN KEY (user_id) REFERENCES mst_user(id)
);


-- DROP TABLE transaction_concert;
-- DROP TABLE concert_detail;
-- DROP TABLE concert_header;
-- DROP TABLE mst_user;
